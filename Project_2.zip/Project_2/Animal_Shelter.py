from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(self):
        # Connection Variables
        USER = 'aacuser'
        PASS = 'your_password_here'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31695
        DB = 'AAC'
        COL = 'animals'

        # Initialize Connection
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

    def create(self, data):
        """Inserts a document into the database. Returns True if successful, else False."""
        if data is not None:
            try:
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print(f"An error occurred: {e}")
                return False
        else:
            raise ValueError("Nothing to save, because data parameter is empty")

    def read(self, criteria=None):
        """Queries for documents matching criteria. Returns a list of documents, or an empty list if none found."""
        if criteria is None:
            criteria = {}

        try:
            documents = list(self.collection.find(criteria))
            return documents
        except Exception as e:
            print(f"An error occurred: {e}")
            return []
    def update(self, query, update_data):
        """Updates a document in the database.

        Args:
            query: A dictionary specifying the document to update.
            update_data: A dictionary specifying the update actions to perform.

        Returns:
            The result of the update operation.
        """
        if not query or not update_data:
            raise ValueError("Query and update_data must be provided")

        try:
            result = self.collection.update_one(query, {'$set': update_data})
            return result.modified_count > 0
        except Exception as e:
            print(f"An error occurred: {e}")
            return False
    def delete(self, query):
        """Deletes a document from the database.

        Args:
            query: A dictionary specifying the document to delete.

        Returns:
            True if a document was deleted, otherwise False.
        """
        if not query:
            raise ValueError("Query must be provided")

        try:
            result = self.collection.delete_one(query)
            return result.deleted_count > 0
        except Exception as e:
            print(f"An error occurred: {e}")
            return False


